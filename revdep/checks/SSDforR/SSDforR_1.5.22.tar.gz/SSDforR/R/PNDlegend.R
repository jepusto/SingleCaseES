PNDlegend <-
function() {
par(mar=c(1, 1, 1, 1))
plot.new()
legend("center", c("Behavior","PND "), col = c("red","gray"), lwd = 1,ncol=2,bty ="n")
}
