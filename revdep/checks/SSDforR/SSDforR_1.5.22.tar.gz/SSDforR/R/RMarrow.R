RMarrow <-
function(X1,Y1,X2,Y2){
   
  #targetindex<-dev.cur() 
  #targetindex<-recordPlot() 
  
   
  
  
  
  arrows(x0=X1,x1=X2,y0=Y1,y1=Y2)
   
   #u<-readline("accept line? (y/n) ")
   #if (u=="n")
   #{replayPlot(targetindex)}
   
  
  
}
