listnames <-
  function(){  
    print(ls("ssd"))
    
  }