PANDlegend <-
function() {
par(mar=c(1, 1, 1, 1))
plot.new()
legend("center", c("Behavior","PAND "), col = c("red","gray"), lwd = 1,ncol=2,bty ="n")
}
