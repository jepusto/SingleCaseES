SN <-
function (value){
  SIG<-formatC(value,digits=5,format="f")
  print(SIG)
}
